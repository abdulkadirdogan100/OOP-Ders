## Nesne Tabanlı Programlama Nedir ?

Nesne tabanlı programlama öncelikle 1960’lı yıllarda başlayan ve    birçok programlama dili tarafından desteklenen bir programlama    tekniğidir.

Bu programlama tekniğine göre her nesne bir sınıfa (class) aittir ve    bu sınıftan türetilir. Her sınıfın özellikleri ( attributes ,    properties ) ve eylemleri  (methods) bulunur . Sınıflar arası bilgi    geçişi içinde miras kalma ( inheritance )  kullanılır.

Örneğin bir araba sınıfı olduğunu düşünelim , bu araba sınıfının özellikleri 4 tekerleğinin ve direksiyonun olması diye düşünelim. Bu araba sınıfında bulunan araba nesnelerine  baktığımızda renklerinin , isimlerinin ve markalarının farklı olduğunu görüyoruz . Ama bu nesnelerin hepsinin bulundukları sınıfın özelliklerini ( 4 tekerleğe ve direksiyona sahip olmak ) taşıdığını yani miras aldığını görüyoruz.