# OOP-19

Nesne Yönelimli Programlama Ders Çalışmaları - 2019 Güz Dönemi Sınıf Listesi:

Ali Osman KAYA

Buket Aydoğan

Rojin Arıkan

Semih GÜLÜM

Sefa DOĞAN

Dilara  GÜRÇAY
 
Seçilay KUTAL

A.Çağatay KİNGİR

Yusufcan YAVİÇ

Burhanettin YILMAZ

Serkan ERAY

Gökhan BAKIRCI

Yusuf Selimhan ÇELİK 

Rasim ALTUNTAŞ

Ulaş Eren ÇINAR

Berkant KESKİN

ÜNAL  ZURNALI

Eyyüp Emre TAN

Zübeyr Talha ÇALIŞKAN

Said Bilal AYKAN

Hüseyin Özen

Destek: Cem GÜÇLÜ

AbdulKadir DOĞAN

