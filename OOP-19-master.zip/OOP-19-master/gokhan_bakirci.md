﻿

## NESNE YÖNELİMLİ PROGRAMLAMANIN TARİHÇESİ


Birçok insan nesne yönelimli programlamanın 1980'lerin bir ürünü olduğuna inanır. Bjarne Stroustrup C dilini, nesne yönelimli programlama dünyasına taşıyarak C++ dilini oluşturmayı başardı. Aslında SIMULA1 ve SIMULA 67 nesne yönelimli dillerin en eski iki tane dilidir. Norveç’in oslo kentinde Norwegian işlem merkezinde Kristen Nygaard ve Ole-John Dahl tarafından SIMULA dillerindeki çalışmalar tamalandı. SIMULA dillerinin önceki sürümlerinde nesne yönelimli programlamanın birçok avantajları erişilebilirken, C++ 1990’larda yerleşik hale gelinceye kadar değildi.

C, C++ dilinin atası olmakla birlikte, deyimsel olarak kendini ayağından birkaç kere vurmaya yetecek kadar güçlü olduğu söylenirdi. Diğer taraftan C++ ise kendini ayağından vurmaya yetecek kadar güçlü olmasa da çok fazla zorluk çekmeden tüm bacağınızı uçurmaya yetecek kadar güçlü bir dildir. Çoğu programcı C++ dilinin çok güçlü bir dil olduğunu kabul eder. Bu düşünce tarzı bugün bile hala yaygındır. Yine de bütün bu güç birtakım karmaşıklıkları da beraberinde getirir. Dil geliştiricleri, nesne yönelimli programlama geliştirmeleri için basit ve daha az kompleks bir dil istemişlerdir.

Nesne yönelimli programlama için bir sonraki adım 1991’in ocak ayında James Gosling, Bill Joy, Patrick Naughton, Mike Sheradin ve birkaç kişi daha Stealth projesi için fikirlerini tartışmak üzere Colorado, Aspen’de biraraya geldiğinde başladı. Grup bir el cihazından merkezi olarak kontrol edilip programlanabilen akıllı elektronik cihazlar geliştirmek istedi. Nesne yönelimli programlamanın gelişim dili için doğru karar olduğunu düşündüler fakat C++’ın bu işi yapamayacağını düşünüyorlardı.
