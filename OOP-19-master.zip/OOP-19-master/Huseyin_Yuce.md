**

# Nesneye Yönelik Analiz (OOA)

**

 - Nesneye Yönelik Analiz (OOA), etkileşimli nesnelerden oluşan bir yazılım sisteminin nesne modeli açısından yazılım mühendisliği gereksinimlerini belirleme ve yazılım özelliklerini geliştirme prosedürüdür.
 - Nesne yönelimli analiz ile diğer analiz biçimleri arasındaki temel fark, nesne yönelimli yaklaşımda gereksinimlerin hem verileri hem de işlevleri birleştiren nesnelerin etrafında düzenlenmesidir. Sistemin etkileşimde olduğu gerçek dünya nesnelerinden modellenmiştir. **

> Geleneksel analiz

** metodolojilerinde, iki özellik - fonksiyonlar ve veriler - ayrı olarak ele alınır.