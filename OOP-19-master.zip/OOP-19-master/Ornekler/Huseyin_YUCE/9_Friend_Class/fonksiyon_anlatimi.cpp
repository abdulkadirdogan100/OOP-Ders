#include <iostream>

int topla(int x, int y);

int main() {
  int z;
  z=topla(5,1);
    std::cout << "Hello, World!" << std::endl;
    return 0;
}

int topla(int x, int y){
    return x+y;
}